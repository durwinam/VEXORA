Local licensed fonts may be placed in this directory.
The UI currently uses Vazirmatn with safe system fallbacks.
